XPeX Systems AI — Public Company Review Pack
Prepared 10 October 2026. Start with docs/company/preparation/COMPANY_OVERVIEW.md.
Seven system dossiers preserve their actual stages. Financial and legal unknowns remain explicit.
This archive contains no private room documents, credentials or customer records.
Factory source correction and production acceptance are separate; inspect dated demo evidence.
Preparation is not investment approval, title verification or independent acceptance.
